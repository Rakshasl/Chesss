class Move:

    def __init__(self):
        pass
