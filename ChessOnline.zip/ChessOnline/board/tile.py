class Tile:

    pieceOnTile = None
    tileCoordinate = None

    def __init__(self, coordinate, piece):
        self.tileCoordinate = coordinate
        self.pieceOnTile = piece



